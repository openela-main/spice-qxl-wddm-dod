QXL-WDDM-DOD
============

Heavily based on Microsoft KMDOD example and XDDM QXL driver

The most recent binaries can be found at https://www.spice-space.org/download/windows/qxl-wddm-dod/
 
