#!/bin/sh -x
# $1 - tag in source repository (usually release tag)
# $2, $3 - none or --scratch --skip-tag
brew \
	win-build \
        rhel-8.3.1-candidate \
	$2 $3 \
	git://git.app.eng.bos.redhat.com/spice/win/spice-qxl-wddm-dod.git#$1 \
	--winspec git://git.app.eng.bos.redhat.com/spice/win/specs.git?qxl-wddm-dod#origin/master \
	rhev-drivers-vs2015-20150723
